const Config = {
  API_BASE_URL: "http://172.20.10.3:3000",
};

export default Config;
